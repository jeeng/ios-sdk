//
//  JeengView.swift
//  JeengSdkIOS
//
//  Created by jeeng on 22/05/2019.
//  Copyright © 2019 jeeng. All rights reserved.
//

import UIKit
import WebKit
import UserNotifications

public class JeengView: UIView {

   
  
    @IBOutlet var webView: UIWebView!
    var action: String = "placeHolder"
    
    
    let nibName = "JeengView"
    var contentView2: UIView!
    
    public override init(frame: CGRect) {
        // For use in code
        super.init(frame: frame)
        setUpView(frame:frame)
    }
    public required init?(coder aDecoder: NSCoder) {
        // For use in Interface Builder
        super.init(coder: aDecoder)
        setUpView(frame:frame)
    }
    @IBAction func click(_ sender: Any) {
              contentView2.isHidden=true
    }
    
    private func setUpView(frame: CGRect) {
        let bundle = Bundle(for: type(of: self))
        let nib = UINib(nibName: self.nibName, bundle: bundle)
        self.contentView2 = nib.instantiate(withOwner: self, options: nil).first as! UIView
        contentView2.frame.size.width = frame.width
        contentView2.frame.size.height = frame.height
        webView.frame.size.width = frame.width
        webView.frame.size.height = frame.height
        addSubview(contentView2)
        contentView2.center = self.center
        contentView2.autoresizingMask = []
        contentView2.translatesAutoresizingMaskIntoConstraints = true
        //let uurl = URL(string:self.action)
        //let rrequest = URLRequest(url: uurl!)
        //self.webView.loadRequest(rrequest)
       
    }
    
    public func getAd(DOMAIN_ID:String)
    {
        let URL_HEROES = "https://jeeng-server.azurewebsites.net/api/push-monetization?domain_id="+DOMAIN_ID+"&user_id=1234567890";
        //creating a NSURL
        let urli = NSURL(string: URL_HEROES)
        
        //fetching the data from the url
        URLSession.shared.dataTask(with: (urli as? URL)!, completionHandler: {(data, response, error) -> Void in
            if let jsonObj = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? NSDictionary {
                //printing the json in console
                //print(jsonObj.value(forKey: "avengers")!)
                self.action = jsonObj.value(forKey: "click_action") as? String ?? "www.ynet.co.il"
                print (self.action)
                let content = UNMutableNotificationContent()
                content.title =  jsonObj.value(forKey: "title") as? String ?? "error"
                content.subtitle = ""
                content.body =  jsonObj.value(forKey: "body") as? String ?? "error"
                content.badge = 1
                content.sound = UNNotificationSound.default
                let identifier = ProcessInfo.processInfo.globallyUniqueString
                var url = NSURL(string: jsonObj.value(forKey: "image") as? String ?? "error")
                var data = NSData(contentsOf : url! as URL)
                var myImage = UIImage(data : data! as Data)
                if let attachment = UNNotificationAttachment.create(identifier: identifier, image: myImage!, options: nil) {
                    content.attachments = [attachment]
                }
                let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
                let requestIdentifier = "notification"
                let request =   UNNotificationRequest(identifier: requestIdentifier, content: content, trigger: trigger)
                UNUserNotificationCenter.current().add(request, withCompletionHandler:{error in})
                let aurl = URL (string:  self.action);
                let arequest = URLRequest(url: aurl!);
                self.webView.loadRequest(arequest);
            }
        }).resume()
    }
}

extension UNNotificationAttachment {
    
    static func create(identifier: String, image: UIImage, options: [NSObject : AnyObject]?) -> UNNotificationAttachment? {
        let fileManager = FileManager.default
        let tmpSubFolderName = ProcessInfo.processInfo.globallyUniqueString
        let tmpSubFolderURL = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent(tmpSubFolderName, isDirectory: true)
        do {
            try fileManager.createDirectory(at: tmpSubFolderURL, withIntermediateDirectories: true, attributes: nil)
            let imageFileIdentifier = identifier+".png"
            let fileURL = tmpSubFolderURL.appendingPathComponent(imageFileIdentifier)
            guard let imageData = image.pngData() else {
                return nil
            }
            try imageData.write(to: fileURL)
            let imageAttachment = try UNNotificationAttachment.init(identifier: imageFileIdentifier, url: fileURL, options: options)
            return imageAttachment
        } catch {
            print("error " + error.localizedDescription)
        }
        return nil
    }
}
