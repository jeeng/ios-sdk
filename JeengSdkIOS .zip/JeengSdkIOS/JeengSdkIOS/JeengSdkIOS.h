//
//  JeengSdkIOS.h
//  JeengSdkIOS
//
//  Created by jeeng on 22/05/2019.
//  Copyright © 2019 jeeng. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for JeengSdkIOS.
FOUNDATION_EXPORT double JeengSdkIOSVersionNumber;

//! Project version string for JeengSdkIOS.
FOUNDATION_EXPORT const unsigned char JeengSdkIOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JeengSdkIOS/PublicHeader.h>


